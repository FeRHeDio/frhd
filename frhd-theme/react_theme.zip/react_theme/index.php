<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package React.dev_Blog
 */

get_header();
?>
    <!-- Start Basic Fallback Content -->
    <div style="max-width: 1200px; margin: 50px auto; padding: 20px; background-color: #fff; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h1 style="color: #149ECA;">React.dev Blog Theme</h1>
        <p>This is a basic fallback display to test if the theme is functioning correctly.</p>
        
        <?php if (have_posts()) : ?>
            <div style="margin-top: 30px;">
                <h2>Recent Posts</h2>
                <ul style="list-style-type: none; padding: 0;">
                <?php while (have_posts()) : the_post(); ?>
                    <li style="margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #eee;">
                        <h3><a href="<?php the_permalink(); ?>" style="color: #149ECA; text-decoration: none;"><?php the_title(); ?></a></h3>
                        <div><?php the_excerpt(); ?></div>
                    </li>
                <?php endwhile; ?>
                </ul>
            </div>
        <?php else : ?>
            <p>No posts found.</p>
        <?php endif; ?>
    </div>
    <!-- End Basic Fallback Content -->

    <div id="primary" class="content-area">
        <main id="main" class="site-main">
            <div class="container">
                <?php
                if (have_posts()) :

                    if (is_home() && !is_front_page()) :
                        ?>
                        <header>
                            <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
                        </header>
                        <?php
                    endif;

                    /* Start the Loop */
                    while (have_posts()) :
                        the_post();

                        /*
                         * Include the Post-Type-specific template for the content.
                         * If you want to override this in a child theme, then include a file
                         * called content-___.php (where ___ is the Post Type name) and that will be used instead.
                         */
                        get_template_part('template-parts/content', get_post_type());

                    endwhile;

                    the_posts_navigation(array(
                        'prev_text' => __('Older posts', 'react-dev-blog'),
                        'next_text' => __('Newer posts', 'react-dev-blog'),
                        'screen_reader_text' => __('Posts navigation', 'react-dev-blog'),
                        'aria_label' => __('Posts', 'react-dev-blog'),
                        'class' => 'pagination',
                    ));

                else :

                    get_template_part('template-parts/content', 'none');

                endif;
                ?>
            </div>
        </main><!-- #main -->
    </div><!-- #primary -->

<?php
get_footer();
