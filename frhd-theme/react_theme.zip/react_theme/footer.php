<footer id="colophon" class="site-footer">
        <div class="container">
            <div class="footer-inner">
                <div class="footer-info">
                    <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
                </div>

                <nav class="footer-nav">
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location' => 'footer',
                            'menu_id'        => 'footer-menu',
                            'container'      => false,
                            'depth'          => 1,
                            'fallback_cb'    => false,
                        )
                    );
                    ?>
                </nav>
            </div>
        </div>
    </footer><!-- #colophon -->
</div><!-- #page -->

<!-- Debug error output -->
<?php 
// Check if template functions file exists
$template_functions_path = get_template_directory() . '/inc/template-functions.php';
if (!file_exists($template_functions_path)) {
    echo '<div style="color: red; background: #fff; padding: 20px; margin: 20px; border: 2px solid red;">';
    echo '<h2>Theme Error:</h2>';
    echo '<p>Critical file missing: ' . $template_functions_path . '</p>';
    echo '<p>This is likely why your theme appears blank.</p>';
    echo '</div>';
}
?>
<!-- End debug output -->

<?php wp_footer(); ?>

</body>
</html>
